// JavaScript Document
$(document).ready(function(){
	$(window).scroll(function(){
		if(this.scrollY > 60){
			$('.navbar').addClass("sticky");
		}else{
			$('.navbar').removeClass("sticky");
		}
	});
	
	// toggle menu script
	$('.menu-hamburger').click(function(){
		$('.navbar .menu').toggleClass("active");
		$('.menu-hamburger i').toggleClass("active");
	});
});